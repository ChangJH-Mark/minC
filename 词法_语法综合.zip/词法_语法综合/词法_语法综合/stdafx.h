#pragma once
#ifndef _STDAFX_H
#define _STDAFX_H
#include"lex.h"
#include"method.h"
#include"block.h"
#include"CodeBlock.h"
#include"define.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#endif // !_STDAFX_H
